// SPDX-License-Identifier: LGPL-3.0-or-later
import type { FSContext } from '@zenfs/core';
import { bindContext, boundContexts, defaultContext, fs } from '@zenfs/core';
import { O_RDWR } from '@zenfs/core/constants';
import { dupFD } from '@zenfs/core/vfs/file.js';
import { UV, withErrno } from 'kerium';
import type { Capabilities } from './capability.js';
import { copy_capabilities, initial_capabilities } from './capability.js';
import { console_tty } from './drivers/tty/console.js';
import type { TTY } from './drivers/tty/tty.js';
import type { SignalHandler, SignalLike } from './signal.js';
import { default_action, sig_kernel_only, Signal, signal_name, signal_of } from './signal.js';
import type { Thread } from './thread.js';
import { WaitQueue } from './wait.js';

export interface ProcessInit {
	argv?: string[];
	env?: Record<string, string>;
	cwd?: string;
	parent?: Process;
	tty?: TTY | null;
	context?: FSContext;
	/**
	 * What to open the standard descriptors on when there is no parent to inherit them from.
	 * @default '/dev/console'
	 */
	console?: string;
}

export const processes = new Map<number, Process>();

/** What each `ITIMER_*` raises when it goes off. */
const itimer_signals: Record<number, Signal> = {
	0: Signal.ALRM,
	1: Signal.VTALRM,
	2: Signal.PROF,
};

/** The process that is running right now, i.e. what `current` points at in Linux. */
export let current: Process | undefined;

export function set_current(proc: Process | undefined): Process | undefined {
	const previous = current;
	current = proc;
	return previous;
}

const kIsProcessExit = Symbol('process.exit');

/** A process, basically the same as `struct task_struct` */
export class Process {
	/** The context this process runs in. Its id is the pid. */
	public readonly context: FSContext;

	/** What the process is running on, once it has been given a program */
	public thread?: Thread;

	/**
	 * The signals userspace asked to handle itself, i.e. the ones with something other than `SIG_DFL`.
	 * The kernel raises these on the thread instead of acting on them.
	 */
	public readonly caught = new Set<Signal>();

	/**
	 * Woken when a signal is raised on the process, so a syscall the kernel is still working on can
	 * come back with `EINTR` instead of leaving the thread waiting on something nobody will finish.
	 */
	public readonly sigwait = new WaitQueue();

	protected readonly _exited = Promise.withResolvers<number>();

	/** Resolves with the exit code once the process has stopped */
	public readonly exited: Promise<number> = this._exited.promise;

	/** Whether the process has stopped but not yet been waited for */
	public get zombie(): boolean {
		return this.code !== undefined;
	}

	/** Whatever forked this process, or whatever adopted it once that exited. */
	public parent?: Process;

	public readonly children = new Set<Process>();

	public argv: string[];
	public env: Record<string, string> = {};

	/** The controlling terminal */
	public readonly tty: TTY | null;

	/** The path of the program currently loaded */
	public exe?: string;

	/** What the process is allowed to do beyond what its uid allows, inherited across a fork */
	public caps: Capabilities;

	/** What the process stopped with, once it has. */
	public code?: number;

	/** The signal that killed the process, if one did */
	public killed_by?: Signal;

	/** Whether a job control signal has stopped the process, like `JOBCTL_STOPPED` */
	public stopped: boolean = false;

	/**
	 * What the process has asked to be told about, like `struct sighand_struct`.
	 * A signal with nothing here gets its {@link default_action}.
	 */
	public readonly sigHandlers = new Map<Signal, Set<SignalHandler>>();

	/** A pid is the id of the process' context. */
	public get pid(): number {
		return this.context.id;
	}

	public get ppid(): number {
		return this.parent?.pid ?? 0;
	}

	/** The name of the program without its path. */
	public get comm(): string {
		return (this.exe ?? this.argv[0] ?? '').split('/').pop() ?? '';
	}

	public constructor(init: ProcessInit = {}) {
		this.parent = init.parent;

		const parent = init.parent?.context ?? defaultContext;
		this.context = init.context ?? bindContext.call(parent, { pwd: init.cwd ?? parent.pwd });

		this.argv = init.argv ?? [];
		this.env = init.env ?? {};
		this.caps = init.parent ? copy_capabilities(init.parent.caps) : initial_capabilities();

		this.tty = init.tty !== undefined ? init.tty : (init.parent?.tty ?? console_tty);

		if (init.parent)
			for (const [fd, handle] of init.parent.context.descriptors) {
				this.context.descriptors.set(fd, handle.ref());
			}
		else {
			const fd = fs.openSync.call(this.context, init.console ?? '/dev/console', O_RDWR);
			dupFD(this.context, fd);
			dupFD(this.context, fd);
		}

		this.parent?.children.add(this);
		processes.set(this.pid, this);
	}

	public get cwd(): string {
		return this.context.pwd;
	}

	public chdir(directory: string): void {
		const target = fs.realpathSync.call(this.context, directory);
		if (!fs.statSync.call(this.context, target)!.isDirectory()) throw UV('ENOTDIR', { syscall: 'chdir', path: target });
		this.context.pwd = target;
		this.env.PWD = target;
	}

	/** Ask to be told when a signal arrives, like `sigaction` with a handler. */
	public sig_action(signal: SignalLike, handler: SignalHandler): void {
		const sig = signal_of(signal);
		if (sig_kernel_only(sig)) throw withErrno('EINVAL', `${signal_name(sig)} cannot be caught or ignored`);

		let handlers = this.sigHandlers.get(sig);
		if (!handlers) this.sigHandlers.set(sig, (handlers = new Set()));
		handlers.add(handler);
	}

	/**
	 * Stop listening for a signal, like going back to `SIG_DFL`.
	 * Without a handler every one installed for the signal is taken off.
	 */
	public sig_default(signal: SignalLike, handler?: SignalHandler): void {
		const sig = signal_of(signal);
		if (!handler) this.sigHandlers.delete(sig);
		else if (this.sigHandlers.get(sig)?.delete(handler) && !this.sigHandlers.get(sig)!.size) this.sigHandlers.delete(sig);
	}

	/** Tell the kernel userspace handles this signal itself, i.e. it is no longer `SIG_DFL` */
	public catch_signal(signal: SignalLike): void {
		const sig = signal_of(signal);
		if (sig_kernel_only(sig)) throw withErrno('EINVAL', `${signal_name(sig)} cannot be caught or ignored`);
		this.caught.add(sig);
	}

	/** Go back to the default action for a signal */
	public uncatch_signal(signal: SignalLike): void {
		this.caught.delete(signal_of(signal));
	}

	/** Send a signal to the process */
	public kill(signal: SignalLike): boolean {
		const sig = signal_of(signal);

		if (this.code !== undefined) return false;

		const handlers = sig_kernel_only(sig) ? undefined : this.sigHandlers.get(sig);

		if (handlers?.size) {
			const name = signal_name(sig);
			for (const handler of [...handlers]) handler(name, sig);
			return true;
		}

		// Userspace asked for this one, so it goes to the thread and runs there
		if (!sig_kernel_only(sig) && this.caught.has(sig) && this.thread) {
			this.thread.raise(sig);
			return true;
		}

		if (this.pid == 1) return false;

		switch (default_action(sig)) {
			case 'ign':
				return false;
			case 'stop':
				this.stopped = true;
				return true;
			case 'cont':
				this.stopped = false;
				return true;
			case 'term':
			case 'core':
				this.killed_by = sig;
				this.exit(128 + sig);
				return true;
		}
	}

	/**
	 * Stop the process.
	 *
	 * What is left is a zombie: it keeps its pid and its exit code until its parent waits for it,
	 * the way Linux keeps one around so a `wait` that comes late still has something to find.
	 */
	public exit(code: number = 0): void {
		if (this.code !== undefined) return;
		this.code = code;

		for (const which of [...this.timers.keys()]) this.setitimer(which, 0, 0);

		this.thread?.kill();
		this.thread = undefined;

		const init = processes.get(1);

		for (const child of [...this.children]) {
			if (!init || init === this) child.exit(child.code ?? 0);
			else {
				this.children.delete(child);
				child.parent = init;
				init.children.add(child);
			}
		}

		for (const fd of [...this.context.descriptors.keys()]) {
			try {
				fs.closeSync.call(this.context, fd);
			} catch {
				// A descriptor that is already gone is not worth failing an exit over
			}
		}

		if (this.tty?.foreground === this) this.tty.foreground = this.parent;

		this._exited.resolve(code);

		// With no parent left to wait for it, there is nothing to keep the zombie around for
		if (!this.parent) this.reap();
	}

	/** Drop what is left of a stopped process, i.e. what a `wait` does once it has the exit code */
	public reap(): void {
		if (this.code === undefined) throw withErrno('ECHILD', 'The process is still running');

		this.parent?.children.delete(this);
		this.parent = undefined;
		processes.delete(this.pid);
		if (this.context !== defaultContext) boundContexts.delete(this.pid);
	}

	/**
	 * Wait for a child to stop and take its exit code.
	 * @param pid which child, or -1 for whichever stops first
	 * @throws ECHILD when there is no such child
	 */
	public async wait(pid: number = -1): Promise<number> {
		if (pid >= 0) {
			const child = processes.get(pid);
			if (!child || child.parent !== this) throw withErrno('ECHILD');

			const code = await child.exited;
			child.reap();
			return code;
		}

		if (!this.children.size) throw withErrno('ECHILD');

		const child = await Promise.race([...this.children].map(async child => (await child.exited, child)));
		const code = child.code!;
		child.reap();
		return code;
	}

	/** Stop the process and drop what is left of it, without anyone waiting for its exit code */
	/**
	 * The interval timers, by `ITIMER_*`, i.e. `signal->real_timer` and the two that count CPU time.
	 */
	protected readonly timers = new Map<number, { started: number; value: number; interval: number; timer: ReturnType<typeof setTimeout> }>();

	/**
	 * Arm or disarm an interval timer, i.e. `setitimer`.
	 */
	public setitimer(which: number, value: number, interval: number): { value: number; interval: number } {
		const previous = this.timers.get(which);

		const remaining = previous ? Math.max(0, previous.started + previous.value - Date.now()) : 0;

		if (previous) {
			clearTimeout(previous.timer);
			this.timers.delete(which);
		}

		if (value > 0) {
			const fire = (): void => {
				if (interval > 0) this.setitimer(which, interval, interval);
				else this.timers.delete(which);

				this.kill(itimer_signals[which] ?? Signal.ALRM);
			};

			this.timers.set(which, { started: Date.now(), value, interval, timer: setTimeout(fire, value) });
		}

		return { value: remaining, interval: previous?.interval ?? 0 };
	}

	public dispose(): void {
		this.exit(this.code ?? 0);
		if (this.code !== undefined && processes.get(this.pid) === this) this.reap();
	}

	public [Symbol.dispose](): void {
		this.dispose();
	}

	static exit = Object.create(Object.assign(Object.create(null), { [kIsProcessExit]: true }));
}

/**
 * Send a signal to a process by pid.
 * @throws ESRCH when there is no such process
 */
export function kill(pid: number, signal: SignalLike = Signal.TERM): boolean {
	const proc = processes.get(pid);
	if (!proc) throw UV('ESRCH', { syscall: 'kill' });
	return proc.kill(signal);
}
