// SPDX-License-Identifier: LGPL-3.0-or-later
/** The process and signal syscalls */
import type { CapFields } from './abi.js';
import { CapData, UtsName } from './abi.js';
import { copyOut, init, syscall } from './base.js';

export { off_signal, on_signal, ready, type SignalHandler } from './base.js';

/** What this process was started with. Empty until the kernel has said. */
export function argv(): string[] {
	return init?.argv ?? [];
}

export function environ(): Record<string, string> {
	return init?.env ?? {};
}

export function getpid(): number {
	return syscall('getpid');
}

export function getppid(): number {
	return syscall('getppid');
}

export function getuid(): number {
	return syscall('getuid');
}

export function geteuid(): number {
	return syscall('geteuid');
}

export function getgid(): number {
	return syscall('getgid');
}

export function getegid(): number {
	return syscall('getegid');
}

/**
 * Stop this process. The kernel tears the thread down, so this never comes back.
 */
export function exit(code: number = 0): never {
	syscall('exit', code);

	// The thread is gone by the time the kernel answers, so this is only here to satisfy the type
	throw new Error('exit returned');
}

/** Start a child running `path`. It inherits the descriptors, the way it would across a fork. */
export function spawn(path: string, argv: string[] = [path], env: Record<string, string> = environ(), cwd?: string): number {
	return syscall('spawn', path, argv, env, cwd);
}

/** Replace what this process is running. Like {@link exit}, the thread does not survive it. */
export function execve(path: string, argv: string[] = [path], env: Record<string, string> = environ()): never {
	syscall('execve', path, argv, env);
	throw new Error('execve returned');
}

/**
 * Block until a child exits.
 * @param pid which child, or -1 for whichever exits first
 * @returns its exit code
 */
export function wait(pid: number = -1): number {
	return syscall('wait', pid);
}

export function kill(pid: number, signal: number): void {
	syscall('kill', pid, signal);
}

export function uname(): UtsName {
	syscall('uname');
	return copyOut(UtsName);
}

export function sethostname(name: string): void {
	syscall('sethostname', name);
}

export function setdomainname(name: string): void {
	syscall('setdomainname', name);
}

export function capget(pid: number = 0): CapData {
	syscall('capget', pid);
	return copyOut(CapData);
}

export function capset(sets: CapFields, pid: number = 0): void {
	syscall('capset', pid, sets.effective, sets.permitted, sets.inheritable);
}
