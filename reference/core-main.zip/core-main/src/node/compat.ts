// SPDX-License-Identifier: LGPL-3.0-or-later
// For backwards compatibility
export * from '../vfs/ioctl.js';
export { chroot, mount, umount } from '../vfs/shared.js';
export * as xattr from '../vfs/xattr.js';
export * from './index.js';

import $pkg from '../../package.json' with { type: 'json' };
export const _version = $pkg.version;
