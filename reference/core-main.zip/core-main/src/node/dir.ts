// SPDX-License-Identifier: LGPL-3.0-or-later
import type { Dir as _Dir, Dirent as _Dirent, OpenDirOptions } from 'node:fs';
import type { V_Context } from '../context.js';
import type { Callback } from '../utils.js';

import { Buffer } from 'buffer';
import type { Exception } from 'kerium';
import { join, parse } from '../path.js';
import { DirType, type Dirent as VFSDirent } from '../vfs/dir.js';
import { readdir } from './promises.js';
import { readdirSync } from './sync.js';

export class Dirent<Name extends string | Buffer = string> implements _Dirent<Name> {
	ino!: number;
	type!: DirType;
	protected _name!: string;

	public get name(): Name {
		const name = Buffer.from(this._name);
		return (this._encoding == 'buffer' ? name : name.toString(this._encoding!)) as Name;
	}

	/**
	 * @internal @protected
	 */
	_encoding?: BufferEncoding | 'buffer' | null;

	/**
	 * @internal @protected
	 */
	_parentPath!: string;

	get parentPath(): string {
		return this._parentPath;
	}

	/**
	 * `vfs.path` is relative to the directory that was read,
	 * so `parentPath` is resolved against it— like Node does.
	 * @internal
	 */
	static from(vfs: VFSDirent, encoding?: BufferEncoding | 'buffer' | null, parentPath: string = '.') {
		const dirent = new Dirent();
		const { base, dir } = parse(vfs.path);
		dirent._parentPath = join(parentPath, dir);
		dirent._name = base;
		dirent.ino = vfs.ino;
		dirent.type = vfs.type;
		dirent._encoding = encoding;
		return dirent;
	}

	isFile(): boolean {
		return this.type === DirType.REG;
	}
	isDirectory(): boolean {
		return this.type === DirType.DIR;
	}
	isBlockDevice(): boolean {
		return this.type === DirType.BLK;
	}
	isCharacterDevice(): boolean {
		return this.type === DirType.CHR;
	}
	isSymbolicLink(): boolean {
		return this.type === DirType.LNK;
	}
	isFIFO(): boolean {
		return this.type === DirType.FIFO;
	}
	isSocket(): boolean {
		return this.type === DirType.SOCK;
	}
}

/**
 * Thrown when a `Dir` is used after it has been closed.
 * Note this is a plain `Error` with a Node error code, not an `Exception`.
 * @internal @hidden
 */
function dirClosed(): Error {
	return Object.assign(new Error('Directory handle was closed'), { code: 'ERR_DIR_CLOSED' });
}

/**
 * A class representing a directory stream.
 */
export class Dir implements _Dir, AsyncIterator<Dirent> {
	protected closed = false;

	protected checkClosed(): void {
		if (this.closed) throw dirClosed();
	}

	protected _entries?: Dirent[];

	public constructor(
		public readonly path: string,
		protected readonly context: V_Context,
		protected readonly options: OpenDirOptions = {},
	) {}

	/**
	 * Asynchronously close the directory's underlying resource handle.
	 * Subsequent reads will result in errors.
	 */
	public close(): Promise<void>;
	public close(cb: Callback): void;
	public close(cb?: Callback): void | Promise<void> {
		const error = this.closed ? dirClosed() : null;
		this.closed = true;
		if (!cb) return error ? Promise.reject(error) : Promise.resolve();
		queueMicrotask(() => cb(error as Exception | null));
	}

	/**
	 * Synchronously close the directory's underlying resource handle.
	 * Subsequent reads will result in errors.
	 */
	public closeSync(): void {
		if (this.closed) throw dirClosed();
		this.closed = true;
	}

	protected async _read(): Promise<Dirent | null> {
		this.checkClosed();
		this._entries ??= await readdir.call<V_Context, [string, any], Promise<Dirent[]>>(this.context, this.path, {
			withFileTypes: true,
			recursive: this.options.recursive,
			encoding: this.options.encoding,
		});
		if (!this._entries.length) return null;
		return this._entries.shift() ?? null;
	}

	/**
	 * Asynchronously read the next directory entry via `readdir(3)` as an `Dirent`.
	 * After the read is completed, a value is returned that will be resolved with an `Dirent`, or `null` if there are no more directory entries to read.
	 * Directory entries returned by this function are in no particular order as provided by the operating system's underlying directory mechanisms.
	 */
	public read(): Promise<Dirent | null>;
	public read(cb: Callback<[Dirent | null]>): void;
	public read(cb?: Callback<[Dirent | null]>): void | Promise<Dirent | null> {
		if (!cb) {
			return this._read();
		}

		this.checkClosed();
		this._read().then(
			value => cb(null, value),
			(error: Exception) => cb(error),
		);
	}

	/**
	 * Synchronously read the next directory entry via `readdir(3)` as a `Dirent`.
	 * If there are no more directory entries to read, null will be returned.
	 * Directory entries returned by this function are in no particular order as provided by the operating system's underlying directory mechanisms.
	 */
	public readSync(): Dirent | null {
		this.checkClosed();
		this._entries ??= readdirSync.call<V_Context, [string, any], Dirent[]>(this.context, this.path, {
			withFileTypes: true,
			recursive: this.options.recursive,
			encoding: this.options.encoding,
		});
		if (!this._entries.length) return null;
		return this._entries.shift() ?? null;
	}

	async next(): Promise<IteratorResult<Dirent>> {
		const value = await this._read();
		if (value) {
			return { done: false, value };
		}

		await this.close();
		return { done: true, value: undefined };
	}

	/**
	 * Asynchronously iterates over the directory via `readdir(3)` until all entries have been read.
	 */
	public [Symbol.asyncIterator](): this {
		return this;
	}

	[Symbol.dispose](): void {
		if (this.closed) return;
		this.closeSync();
	}

	public async [Symbol.asyncDispose]() {
		if (this.closed) return;
		await this.close();
	}
}
